from opensimplex import OpenSimplex
seed = OpenSimplex(100)
seed.noise2d(0, 100)